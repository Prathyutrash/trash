var data;
 function getData(){
      var xmlHttp = new XMLHttpRequest();
      var word= document.getElementById("movie").value;
      var url = "https://api.themoviedb.org/3/search/movie?api_key=628feb1e5d19aa715bd6f0824546c81d&query="+word;
      
      xmlHttp.onreadystatechange = function() {
       if(this.status == 404) {
        document.getElementById('titlemovie1').innerHTML = "404<br><h1>Movie Not Found</h1>";
       }
          if(this.readyState == 4 && this.status == 200){
              data= JSON.parse(this.responseText);
              var htmlText = '';
              for ( var i=0;i<data.results.length;i++ ) {
                  console.log(data.results[i].title);
                  if(i%2==0)
                   htmlText += '<div class="div-conatiner">';
                  htmlText += '<div class="col-sm-4 col-lg-8 m-2 p-2">';
                  htmlText += '<h3 class="p-name display-5 heading" id="moviename">' + data.results[i].title + '</h3>';
                  htmlText += '<p class="p-loc lead"> <img src="http://image.tmdb.org/t/p/w500' + data.results[i].poster_path + '" class="img-fluid"></p>';
                  htmlText += '<p class="p-desc lead"> Description: ' + data.results[i].overview + '</p>';
                  htmlText += '<p class="p-created lead"> Released on: ' + data.results[i].release_date + '</p>';
                  htmlText += '<button class="button button-secondary" onClick="addFav()" >Add to favourites</button>';
                  htmlText += '<script type="text/javascript" src="MovieServlet.java"></script>';
                  htmlText += '<input type="button" value="Remove Favourite" />';
                  htmlText += '</div>'
                  if(i%2==0)
                   htmlText += '</div><hr>';
              }
           document.getElementById('titlemovie1').insertAdjacentHTML('afterend',htmlText);  
          
          }
      };
      xmlHttp.open("GET",url,true);
      xmlHttp.send();
    }
 function addFav() {
  var xmlhttp = new XMLHttpRequest();
  
  xmlhttp.onreadystatechange = function(){
   if(xmlhttp.readyState == 4 && xmlhttp.status == 200){
    document.getElementById("mydiv").innerHTML = xmlhttp.responseText;
   }
  };
  
  xmlhttp.open('POST',"http://localhost:8081/moviez/JsonReader", true);
  xmlhttp.send(data);
 }