package Main;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class saveData extends HttpServlet{
	public void service(HttpServletRequest req,HttpServletResponse res) {
		
	}
}
